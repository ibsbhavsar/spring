package com.liferay.controller.portlet;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.liferay.controller.constants.EmployeeControllerPortletKeys;
import com.liferay.counter.kernel.service.CounterLocalService;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.dao.search.SearchContainer;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import EmployeeCrud.model.Employee;
import EmployeeCrud.service.EmployeeLocalService;

/**
 * @author bhavin.bhavsar
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=EmployeeMVC",
		"com.liferay.portlet.instanceable=true", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + EmployeeControllerPortletKeys.EmployeeController,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class EmployeeControllerPortlet extends MVCPortlet {

	@Reference
	private EmployeeLocalService employeeLocalService;

	@Reference
	private CounterLocalService counterLocalService;

	private static final Log _log = LogFactoryUtil.getLog(EmployeeControllerPortlet.class);

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		Employee employee = (Employee) renderRequest.getAttribute("employee");
		if (Validator.isNull(employee)) {
			List<Employee> employeeList = null;
			PortletURL iteratorURL = renderResponse.createRenderURL();
			SearchContainer<Employee> searchContainer = null;
			searchContainer = new SearchContainer<Employee>(renderRequest, null, null,
					SearchContainer.DEFAULT_CUR_PARAM,4, iteratorURL, null, StringPool.BLANK);
			searchContainer.setEmptyResultsMessage("There is no data to display");
			employeeList = employeeLocalService.getEmployees(searchContainer.getStart(), searchContainer.getEnd());
			searchContainer.setResults(employeeList);
			searchContainer.setTotal(employeeList.size());
			searchContainer.setIteratorURL(iteratorURL);
			renderRequest.setAttribute("employeeSearchContainer", searchContainer);
			renderRequest.setAttribute("employeeList", employeeList);
		}
		super.render(renderRequest, renderResponse);
	}

	public void addUpdateData(ActionRequest actionRequest, ActionResponse actionResponse) {
		if (Validator.isNotNull(actionRequest.getParameter("id"))) {
			try {
				Employee employee = employeeLocalService.getEmployee(ParamUtil.getLong(actionRequest, "id"));
				addEmployee(actionRequest, employee);
				employeeLocalService.updateEmployee(employee);
				_log.info("Data updated");
			} catch (Exception e) {
			}
		} else {
			Employee employee = employeeLocalService.createEmployee(counterLocalService.increment());
			addEmployee(actionRequest, employee);
			employeeLocalService.addEmployee(employee);
			_log.info("Employee added");
		}
	}

	public void addEmployee(ActionRequest actionRequest, Employee employee) {
		employee.setName(ParamUtil.getString(actionRequest, "name"));
		employee.setAge(ParamUtil.getInteger(actionRequest, "age"));
		employee.setCity(ParamUtil.getString(actionRequest, "city"));
		employee.setState(ParamUtil.getString(actionRequest, "state"));
		employee.setCountry(ParamUtil.getString(actionRequest, "country"));
		employee.setContactno(ParamUtil.getLong(actionRequest, "contactno"));
		employee.setQualification(ParamUtil.getString(actionRequest, "qualification"));
	}

	public void editEmployee(ActionRequest actionRequest, ActionResponse actionResponse) {
		SessionMessages.add(actionRequest,
				PortalUtil.getPortletId(actionRequest) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_SUCCESS_MESSAGE);
		long id = ParamUtil.getLong(actionRequest, "id");
		Employee employee = null;
		try {
			employee = employeeLocalService.getEmployee(id);
		} catch (Exception e) {
		}
		actionRequest.setAttribute("employee", employee);
		actionResponse.setRenderParameter("mvcPath", "/form.jsp");
	}

	public void deleteEmployee(ActionRequest actionRequest, ActionResponse actionResponse) {
		try {
			employeeLocalService.deleteEmployee(ParamUtil.getLong(actionRequest, "id"));
			_log.info("Data deleted");
		} catch (Exception e) {

		}
	}

}