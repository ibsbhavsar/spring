package com.liferay.controller.constants;

/**
 * @author bhavin.bhavsar
 */
public class EmployeeControllerPortletKeys {

	public static final String EmployeeController = "employeecontroller";

}